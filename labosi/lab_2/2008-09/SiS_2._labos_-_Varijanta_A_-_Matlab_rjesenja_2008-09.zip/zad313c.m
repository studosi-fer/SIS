%313c

fs=8000;
N=8000;
t=0:1/(fs):1;
x2=sin(2*pi*805*t);
length(x2)
plot([0:N],x2);
