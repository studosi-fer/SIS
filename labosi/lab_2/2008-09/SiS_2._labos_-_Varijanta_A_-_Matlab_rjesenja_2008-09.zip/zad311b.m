%311b

n=[1 1 1 1 1];
n0=2;
[H,w]=freqz(n,1,[-5*pi:0.1:5*pi]);
H=H.*exp(-j*w*n0);
subplot(211), plot(w,abs(H));
subplot(212), plot(w,phase(H));
