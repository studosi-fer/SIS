%312c

H=abs(H).*abs(H);
E=sum(H)
