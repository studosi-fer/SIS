%331b

%x1(t)
t=[-2:0.01:5];
subplot(311), plot(t, x1(t), 'b'), grid, axis([-2 5 -1 3]), xlabel('t'), ylabel('x1(t)')

%x2(t)
t=[-6:0.01:6];
subplot(312), plot(t, x2(t), 'b'), grid, axis([-6 6 -2 2]), xlabel('t'), ylabel('x2(t)')

%y1(t)
t=[-2:0.01:6];
subplot(313), plot(t, y1(t), 'b'), grid, axis([-2 6 -1 3]), xlabel('t'), ylabel('y1(t)')
