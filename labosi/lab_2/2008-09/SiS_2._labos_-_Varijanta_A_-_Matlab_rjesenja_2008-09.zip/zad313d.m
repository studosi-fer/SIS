%313d

X=fft(x2);
A=abs(X);
N2=length(X);
w=([1:N2]-1)/N2*fs;
plot(w,A);
