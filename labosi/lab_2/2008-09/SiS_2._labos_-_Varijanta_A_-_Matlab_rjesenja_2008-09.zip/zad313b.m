%313b

X=fft(x1);
A=abs(X);
N=length(X);
w=([1:N]-1)/N*fs;
plot(w,A);
